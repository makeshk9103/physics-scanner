# Physics Scanner (offline)
Camera scan -> ML Kit OCR (offline) -> MCQ parse -> formula retrieval -> on-device LLM -> answer + steps.

## APK eppadi vaangurathu (Android Studio thevai illa)
1. github.com la oru free repo create pannunga.
2. Indha folder contents-ah (zip unzip panni) repo-la upload pannunga (.github folder include aaganum).
3. Repo -> Actions tab -> "Build APK" -> Run workflow. ~5-8 min.
4. Mudinja apram "PhysicsScanner-APK" artifact download -> unzip -> app-debug.apk -> phone la install.

## First launch
App open panni "Download model (one-time)" thattunga (WiFi, ~1.6 GB). Adhukku apram full offline.
Illa already model file irundha "Pick model file" use pannunga.
