package com.makesh.physicsscanner

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** Runs a small on-device LLM. Put model at: <externalFilesDir>/model.task */
class LlmEngine(private val context: Context) {
    private var llm: LlmInference? = null

    fun modelFile() = File(context.getExternalFilesDir(null), "model.task")

    fun ready(): Boolean = modelFile().exists()

    private fun ensure(): LlmInference {
        llm?.let { return it }
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile().absolutePath)
            .setMaxTokens(1024)
            .build()
        return LlmInference.createFromOptions(context, opts).also { llm = it }
    }

    fun solve(mcq: Mcq, hints: List<String>): String {
        val sb = StringBuilder()
        sb.appendLine("You are a physics expert for CSIR NET / TIFR / JEST level MCQs.")
        if (hints.isNotEmpty()) {
            sb.appendLine("Useful formulas:"); hints.forEach { sb.appendLine("- $it") }
        }
        sb.appendLine("\nQuestion: ${mcq.stem}")
        mcq.options.forEach { (k, v) -> sb.appendLine("($k) $v") }
        sb.appendLine("\nSolve step by step briefly, then end with exactly: Answer: <letter>")
        return ensure().generateResponse(sb.toString())
    }
}
