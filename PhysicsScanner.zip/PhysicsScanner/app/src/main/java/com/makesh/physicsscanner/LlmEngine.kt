package com.makesh.physicsscanner

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** Runs a small on-device LLM. Model at: <externalFilesDir>/model.task */
class LlmEngine(private val context: Context) {
    private var llm: LlmInference? = null

    fun modelFile() = File(context.getExternalFilesDir(null), "model.task")
    fun ready(): Boolean = modelFile().exists()

    private fun ensure(): LlmInference {
        llm?.let { return it }
        val opts = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelFile().absolutePath)
            .setMaxTokens(512)
            .build()
        return LlmInference.createFromOptions(context, opts).also { llm = it }
    }

    /** Load the model in background at app start so the first scan is fast. */
    fun warmUp() { if (ready()) ensure() }

    /** Fast mode: model replies with just the option letter (few tokens). */
    fun solve(mcq: Mcq): String {
        val sb = StringBuilder()
        sb.appendLine("You are a physics expert. Choose the correct option. Reply with only the option letter.")
        sb.appendLine("Question: ${mcq.stem}")
        mcq.options.forEachIndexed { i, o -> sb.appendLine("${'A' + i}) $o") }
        sb.append("Answer:")
        return ensure().generateResponse(sb.toString())
    }
}
