package com.makesh.physicsscanner

data class Mcq(val stem: String, val options: List<String>)

object McqParser {
    private val strong = Regex("""^\(?([A-Da-d])[\)\.\]:]\s*(.*)$""")
    private val weak = Regex("""^\s*(\(?[A-Da-d1-4][\)\.\]:]|[a-d])\s+""")

    fun clean(raw: String): String = raw
        .replace("\u2212", "-").replace("×", "x").replace("–", "-")
        .replace(Regex("[ \t]+"), " ").trim()

    fun parse(raw: String): Mcq {
        val lines = clean(raw).lines().map { it.trim() }.filter { it.isNotEmpty() }
            // junk: website/watermark lines
            .filterNot { it.contains("www.", true) || it.contains(".com", true) || it.contains("http", true) }
            // junk: stray single letters A-D (OCR leftovers)
            .filterNot { it.length == 1 && it[0].uppercaseChar() in 'A'..'D' }

        // 1) Clearly labelled options: A) / B. / (c) ...
        val strongIdx = lines.indices.filter { strong.matches(lines[it]) }
        if (strongIdx.size >= 3) {
            val first = strongIdx.first()
            val stem = lines.take(first).joinToString(" ")
            val opts = mutableListOf<String>()
            for (i in first until lines.size) {
                val m = strong.find(lines[i])
                if (m != null) opts.add(m.groupValues[2].trim())
                else if (opts.isNotEmpty()) opts[opts.lastIndex] = opts.last() + " " + lines[i]
            }
            return Mcq(stem, opts.take(4))
        }

        // 2) Labels missing/garbled: last 4 lines = options, rest = question
        return if (lines.size >= 5) {
            Mcq(lines.dropLast(4).joinToString(" "), lines.takeLast(4).map { weak.replace(it, "") })
        } else {
            Mcq(lines.firstOrNull() ?: "", lines.drop(1).map { weak.replace(it, "") })
        }
    }
}
