package com.makesh.physicsscanner

data class Mcq(val stem: String, val options: Map<String, String>)

object McqParser {
    // Matches (A) / A) / A. / a) at line start
    private val optRegex = Regex("""^\s*\(?([A-Da-d1-4])[\)\.\]]\s*(.+)$""")

    fun clean(raw: String): String = raw
        .replace("\u2212", "-").replace("×", "x").replace("–", "-")
        .replace(Regex("[ \t]+"), " ").trim()

    fun parse(raw: String): Mcq {
        val stem = StringBuilder()
        val opts = linkedMapOf<String, String>()
        for (line in clean(raw).lines()) {
            val m = optRegex.find(line)
            if (m != null) {
                val key = m.groupValues[1].uppercase().let { if (it in "1234") "ABCD"[it.toInt() - 1].toString() else it }
                opts[key] = m.groupValues[2].trim()
            } else if (opts.isEmpty()) stem.appendLine(line)
            else opts[opts.keys.last()] = opts.getValue(opts.keys.last()) + " " + line.trim()
        }
        return Mcq(stem.toString().trim(), opts)
    }
}
