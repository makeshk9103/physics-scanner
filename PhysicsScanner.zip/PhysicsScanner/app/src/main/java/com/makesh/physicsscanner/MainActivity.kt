package com.makesh.physicsscanner

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

@androidx.camera.core.ExperimentalGetImage
class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val camExecutor = Executors.newSingleThreadExecutor()
    private var capture: ImageCapture? = null
    private var camera: Camera? = null
    private var torchOn = false
    private var busy = false
    private lateinit var engine: LlmEngine

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera() else output.text = "Camera permission venum."
        }

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            output.text = "Model copy aagudhu..."
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)!!.use { i ->
                        engine.modelFile().outputStream().use { o -> i.copyTo(o) }
                    }
                }
                refreshSetup()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        output = findViewById(R.id.output)
        engine = LlmEngine(this)
        findViewById<Button>(R.id.scanBtn).setOnClickListener { scan() }
        findViewById<Button>(R.id.torchBtn).setOnClickListener {
            torchOn = !torchOn
            camera?.cameraControl?.enableTorch(torchOn)
        }
        findViewById<Button>(R.id.downloadBtn).setOnClickListener { downloadModel() }
        findViewById<Button>(R.id.pickBtn).setOnClickListener { picker.launch(arrayOf("*/*")) }
        refreshSetup()
        // load model in background so first answer is quick
        lifecycleScope.launch(Dispatchers.Default) { try { engine.warmUp() } catch (_: Exception) {} }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun refreshSetup() {
        val ok = engine.ready()
        findViewById<View>(R.id.setupRow).visibility = if (ok) View.GONE else View.VISIBLE
        output.text = if (ok) "Ready! Question mela camera point panni Scan thattunga. Iruttu-na 'Light' thattunga."
        else "First time setup: 'Download model' thattunga (WiFi la, ~1.6 GB). Idhu oru vaati dhaan, apram offline."
    }

    private fun downloadModel() {
        output.text = "Downloading... 0%"
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ModelDownloader.download(engine.modelFile()) { pct ->
                        runOnUiThread { output.text = "Downloading... $pct%  (app close panadhinga)" }
                    }
                }
                refreshSetup()
                launch(Dispatchers.Default) { try { engine.warmUp() } catch (_: Exception) {} }
            } catch (e: Exception) {
                output.text = "Download fail: ${e.message}. Marupadi try pannunga."
            }
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(findViewById<PreviewView>(R.id.preview).surfaceProvider) }
            capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
            provider.unbindAll()
            camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scan() {
        val cap = capture ?: return
        if (busy) return
        busy = true
        output.text = "Scanning..."
        cap.takePicture(camExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val media = image.image
                if (media == null) { image.close(); busy = false; return }
                val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
                recognizer.process(input)
                    .addOnSuccessListener { res -> image.close(); answer(res.text) }
                    .addOnFailureListener { e ->
                        image.close(); busy = false
                        runOnUiThread { output.text = "OCR error: ${e.message}" }
                    }
            }
            override fun onError(e: ImageCaptureException) {
                busy = false
                runOnUiThread { output.text = "Capture error: ${e.message}" }
            }
        })
    }

    private fun answer(raw: String) {
        val mcq = McqParser.parse(raw)
        if (mcq.stem.isBlank() || mcq.options.size < 2) {
            output.text = "Question/options clear-ah padikka mudiyala. Nalla velicham, straight-ah vechi marupadi scan pannunga.\n\nPadicha text:\n$raw"
            busy = false; return
        }
        val shown = buildString {
            appendLine("Q: ${mcq.stem}"); appendLine()
            mcq.options.forEachIndexed { i, o -> appendLine("${'A' + i}) $o") }
        }
        if (!engine.ready()) { refreshSetup(); busy = false; return }
        output.text = shown + "\nYosikkudhu..."
        lifecycleScope.launch {
            try {
                val reply = withContext(Dispatchers.Default) { engine.solve(mcq) }
                val letter = Regex("\\b([A-D])\\b").find(reply)?.groupValues?.get(1)
                val idx = letter?.let { it[0] - 'A' }
                output.text = shown + "\n" +
                    if (idx != null && idx < mcq.options.size) "✅ Answer: $letter) ${mcq.options[idx]}"
                    else "Answer: ${reply.trim()}"
            } catch (e: Exception) {
                output.text = shown + "\nError: ${e.message}"
            }
            busy = false
        }
    }
}
