package com.makesh.physicsscanner

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import android.view.View
import android.net.Uri
import java.io.File

@androidx.camera.core.ExperimentalGetImage
class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val camExecutor = Executors.newSingleThreadExecutor()
    private var capture: ImageCapture? = null
    private lateinit var engine: LlmEngine
    private lateinit var formulas: FormulaStore

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) startCamera() else output.text = "Camera permission venum."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        output = findViewById(R.id.output)
        engine = LlmEngine(this)
        formulas = FormulaStore(this)
        findViewById<Button>(R.id.scanBtn).setOnClickListener { scan() }
        findViewById<Button>(R.id.downloadBtn).setOnClickListener { downloadModel() }
        findViewById<Button>(R.id.pickBtn).setOnClickListener { picker.launch(arrayOf("*/*")) }
        refreshSetup()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) startCamera()
        else permLauncher.launch(Manifest.permission.CAMERA)
    }

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            output.text = "Model copy aagudhu..."
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)!!.use { i ->
                        engine.modelFile().outputStream().use { o -> i.copyTo(o) }
                    }
                }
                refreshSetup()
            }
        }

    private fun refreshSetup() {
        val ok = engine.ready()
        findViewById<View>(R.id.setupRow).visibility = if (ok) View.GONE else View.VISIBLE
        output.text = if (ok) "Ready! Question mela camera point panni Scan thattunga."
        else "First time setup: 'Download model' thattunga (WiFi la, ~1.6 GB). Idhu oru vaati dhaan, apram offline."
    }

    private fun downloadModel() {
        output.text = "Downloading... 0%"
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ModelDownloader.download(engine.modelFile()) { pct ->
                        runOnUiThread { output.text = "Downloading... $pct%  (app close panadhinga)" }
                    }
                }
                refreshSetup()
            } catch (e: Exception) {
                output.text = "Download fail: ${e.message}. Marupadi try pannunga."
            }
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(findViewById<PreviewView>(R.id.preview).surfaceProvider) }
            capture = ImageCapture.Builder().build()
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scan() {
        val cap = capture ?: return
        output.text = "Scanning..."
        cap.takePicture(camExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val media = image.image
                if (media == null) { image.close(); return }
                val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
                recognizer.process(input)
                    .addOnSuccessListener { res -> image.close(); answer(res.text) }
                    .addOnFailureListener { e -> image.close(); runOnUiThread { output.text = "OCR error: ${e.message}" } }
            }
            override fun onError(e: ImageCaptureException) {
                runOnUiThread { output.text = "Capture error: ${e.message}" }
            }
        })
    }

    private fun answer(raw: String) {
        val mcq = McqParser.parse(raw)
        runOnUiThread { output.text = "Question:\n${mcq.stem}\n\nSolving..." }
        if (!engine.ready()) {
            runOnUiThread { refreshSetup() }
            return
        }
        lifecycleScope.launch {
            val reply = withContext(Dispatchers.Default) {
                engine.solve(mcq, formulas.topK(mcq.stem + " " + mcq.options.values.joinToString(" ")))
            }
            output.text = "Question:\n${mcq.stem}\n\n$reply"
        }
    }
}
