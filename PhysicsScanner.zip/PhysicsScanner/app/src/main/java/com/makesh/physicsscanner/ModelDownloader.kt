package com.makesh.physicsscanner

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object ModelDownloader {
    // Open (non-gated, Apache-2.0) Qwen2.5-1.5B-Instruct, MediaPipe .task format, ~1.6 GB
    const val URL_STR =
        "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"

    /** Blocking. Call from a background thread. onProgress(percent). */
    fun download(target: File, onProgress: (Int) -> Unit) {
        val part = File(target.parentFile, target.name + ".part")
        val conn = (URL(URL_STR).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000; readTimeout = 30000; instanceFollowRedirects = true
        }
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            part.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L; var last = -1
                while (true) {
                    val n = input.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != last) { last = pct; onProgress(pct) }
                    }
                }
            }
        }
        if (!part.renameTo(target)) throw IllegalStateException("Rename failed")
    }
}
