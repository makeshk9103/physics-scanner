package com.makesh.physicsscanner

import android.content.Context

/** Tiny offline retrieval: picks the formula-note lines that best overlap the question. */
class FormulaStore(context: Context) {
    private val lines: List<String> =
        context.assets.open("formulas.txt").bufferedReader().readLines().filter { it.isNotBlank() }

    private fun tokens(s: String) =
        s.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length > 2 }.toSet()

    fun topK(question: String, k: Int = 5): List<String> {
        val q = tokens(question)
        return lines.map { it to tokens(it).intersect(q).size }
            .filter { it.second > 0 }.sortedByDescending { it.second }.take(k).map { it.first }
    }
}
